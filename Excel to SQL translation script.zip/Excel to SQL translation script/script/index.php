<?php
$connect = mysqli_connect("localhost", "root", "", "sotrudniki"); //Подключаемся к БД
$output = '';
if (isset($_POST["import"])) {
    $extension = end(explode(".", $_FILES["excel"]["name"])); // Получаем расширение файла
    $allowed_extension = array("xls", "xlsx", "csv"); // Разрешенные расширения
    if (in_array($extension, $allowed_extension)) { //Проверяем наличие выбранного расширения в массиве разрешенных
        $file = $_FILES["excel"]["tmp_name"]; // Получаем временный источник
        include("PHPExcel/IOFactory.php"); // Подключаем нужную библиотеку
        $objPHPExcel = PHPExcel_IOFactory::load($file); // создаём объект библиотеки и определяем путь к файлу

        $output .= "<label class='text-success'>Данные вставлены</label><br /><table class='table table-bordered'>";
        foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {       //
            $highestRow = $worksheet->getHighestRow();                       //Запускаем циклы для прохода по строкам
            for ($row = 2; $row <= $highestRow; $row++) {                    //
                $output .= "<tr>";

                //Получаем данные
                $name = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(0, $row)->getValue());        
                $date = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(1, $row)->getFormattedValue()); 
                $date = date('Y-m-d', strtotime($date));
                $skill = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(2, $row)->getValue());     

                $query = "INSERT INTO exceltosql(name, date_birth, skill) VALUES ('" . $name . "', '" . $date . "', '" . $skill . "')";
                mysqli_query($connect, $query); //Сформировали запрос к БД на добавление данных и добавили их

                $output .= '<td>' . $name . '</td>'; //
                $output .= '<td>' . $date . '</td>'; //Выводим для наглядности
                $output .= '<td>' . $skill . '</td>'; //
                $output .= '</tr>';
            }
        }
        $output .= '</table>';
    } else {
        $output = '<label class="text-danger">Неподходящий файл</label>';
    }
}
?>

<html>

    <head>
        <title>Экспорт содержимого Excel файла в БД MySQL</title>
        
    </head>

    <body>
        <div class="container box">
            <h3>Экспорт содержимого Excel файла в БД MySQL</h3><br />
            <form method="post" enctype="multipart/form-data">
                
                <input type="file" name="excel" />
                <br />
                <input type="submit" name="import" class="btn btn-info" value="Отправить" />
            </form>
            <br />
            <br />
<?php echo $output; ?>
        </div>
    </body>

</html>
